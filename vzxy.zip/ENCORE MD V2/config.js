require("./Encore")
const fs = require('fs')
const { version } = require("./package.json")
//~~~~~~~~~SETTING BOT~~~~~~~~~~//

// Bebas Ubah
global.owner = "6282135574623"
global.nobot = "6285124585608"
global.namaowner = "𝚀𝚎𝚗𝙾𝚏𝚏𝚌"
global.namaBot = "𝚅𝚣𝚡𝚢𝙱𝚘𝚝𝚣 - ᴍᴅ"
global.title = "𝚅𝚣𝚡𝚢𝙱𝚘𝚝𝚣"

// Jangan Di ubah
global.creator = `${owner}@s.whatsapp.net` 
global.foother = `© ${namaBot}`
global.versi = version
global.nama = namaBot 
global.namach = nama 
global.namafile = foother 
global.author = namaowner

// Bebas Ubah
// True = on || False = Off 
global.autoread = true
global.autotyping = false
global.Antilinkgc = false
global.Antilinkch = false
global.antispam = false
global.onlygc = false
global.autobio = false

// Set Payment
global.qris = "https://files.catbox.moe/gy2jzt"
global.dana = "085743127108"
global.gopay = "085743127108"

// ===={ Set Link }
global.ch = 'https://whatsapp.com/channel/0029VayiGBeD8SE1xNogpm3h'
global.idch = '120363355773604642@newsletter'
global.linkgc = 'https://chat.whatsapp.com/Dqs9rBPzA5kFCucZQD7OKq?mode=ems_copy_t'
global.yt = 'https://youtube.com/@qenoffc'
global.nekorin = "https://api.nekorinn.my.id"
global.idgc = "120363355773604642@g.us"
// set prefix
global.setprefix = ".", "/", "#"

// User Sosmed
global.tt = "@qenoffc"
global.yt = "@qenoffc"
global.ig = "@qenoffc"

// Setting Api cVPS
global.doToken = "APIKEY"
global.linodeToken = "APIKEY"

// Settings Api Panel Pterodactyl
global.egg = "17" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://panell.cloudshop.web.id"
global.apikey = "ptla_VfAihxNWpBsAUGLzKIvqmq44MDlwwcoLUsOvTgyVsps" //ptla
global.capikey = "ptlc_dC0fWQvOxSxtnwi1ZS40W5COpXwM1bQFa6BlWl7ViQv" //ptlc

// [ THEME URL & URL ] ========//
global.thumbnail = 'https://img1.pixhost.to/images/8567/638832946_lily.jpg'
global.thumnail2 = 'https://img1.pixhost.to/images/8575/638910466_lily.jpg'

// Settings reply ~~~~~~~~~//
global.mess = {
    owner: "Khusus Owner",
    prem: "Khusus Premium",
    group: "Khusus di Group Chat",
    admin: "Khusus Admin",
    botadmin: "Bot Harus Jadi Admin",
    private: "Khusus di Private Chat",
    done: "Sukses"
}

global.packname = nama
global.author = namaBot

//
global.gamewaktu = 60 // Game waktu
global.suit = {};
global.tictactoe = {};
global.petakbom = {};
global.kuis = {};
global.siapakahaku = {};
global.asahotak = {};
global.susunkata = {};
global.caklontong = {};
global.family100 = {};
global.tebaklirik = {};
global.tebaklagu = {};
global.tebakgambar2 = {};
global.tebakkimia = {};
global.tebakkata = {};
global.tebakkalimat = {};
global.tebakbendera = {};
global.tebakanime = {};
global.kuismath = {};

//~~~~~~~~~~~ DIEMIN ~~~~~~~~~~//

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
