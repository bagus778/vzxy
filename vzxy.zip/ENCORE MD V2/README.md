#Script Arisu-MD
*Base By Kyami Silence*
*Pengembang Script Zion Dev*
*Baileys By Kiuur*

#Script ini gratis Dari Zion
#Dilarang Menjual Belikan

#Sumber
#https://whatsapp.com/channel/0029Vb2K7scK0IBkPoAGgk28
