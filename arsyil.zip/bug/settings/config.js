global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6285743127108']

global.autoRecording = true // ubah jadi true untuk menyalakan auto typing